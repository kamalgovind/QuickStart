## [v0.3.0]
> Mar 24, 2017

- More names.

[v0.3.0]: https://github.com/rstacruz/startup-name-generator/compare/v0.2.1...v0.3.0

## [v0.2.1]
> Mar 20, 2017

- Fix distribution package not being packaged.

[v0.2.1]: https://github.com/rstacruz/startup-name-generator/compare/v0.2.0...v0.2.1

## [v0.2.0]
> Mar 20, 2017

- Add a distribution package via [unpkg.com](https://unpkg.com/@rstacruz/startup-name-generator@latest/lib/index.js).

[v0.2.0]: https://github.com/rstacruz/startup-name-generator/compare/v0.1.1...v0.2.0

## [v0.1.1]
> Mar 17, 2017

- Fix `main` entry in package.json.

[v0.1.1]: https://github.com/rstacruz/startup-name-generator/compare/v0.1.0...v0.1.1

## [v0.1.0]
> Mar 17, 2017

- Initial release.

[v0.1.0]: https://github.com/rstacruz/startup-name-generator/tree/v0.1.0

